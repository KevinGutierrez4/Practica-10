
const API_URL = "http://localhost:3000/api";

// ==========================================
// PRODUCTOS
// ==========================================

// Obtener productos
export async function obtenerProductos(buscar = "", categoriaId = "") {
    const parametros = new URLSearchParams({
        pagina: "1",
        limite: "100",
        buscar
    });

    if (categoriaId) {
        parametros.append("categoriaId", categoriaId);
    }

    const respuesta = await fetch(
        `${API_URL}/productos?${parametros}`
    );

    if (!respuesta.ok) {
        throw new Error("Error al obtener productos");
    }

    const resultado = await respuesta.json();

    return resultado.datos;
}

// Obtener un producto por ID
export async function obtenerProducto(id) {
    const respuesta = await fetch(`${API_URL}/productos/${id}`);

    const resultado = await respuesta.json();

    if (!respuesta.ok) {
        throw new Error(resultado.mensaje || "Error al obtener producto");
    }

    return resultado.datos;
}

// Crear producto
export async function crearProducto(producto) {
    return enviar(`${API_URL}/productos`, "POST", producto);
}

// Actualizar producto
export async function actualizarProducto(id, producto) {
    return enviar(`${API_URL}/productos/${id}`, "PUT", producto);
}

// Eliminar producto
export async function eliminarProducto(id) {
    return enviar(`${API_URL}/productos/${id}`, "DELETE");
}

// ==========================================
// CATEGORÍAS
// ==========================================

// Obtener todas las categorías
export async function obtenerCategorias() {
    const respuesta = await fetch(`${API_URL}/categorias`);

    if (!respuesta.ok) {
        throw new Error("Error al obtener categorías");
    }

    const resultado = await respuesta.json();

    return resultado.datos;
}

// Obtener una categoría por ID
export async function obtenerCategoria(id) {
    const respuesta = await fetch(`${API_URL}/categorias/${id}`);

    const resultado = await respuesta.json();

    if (!respuesta.ok) {
        throw new Error(resultado.mensaje || "Error al obtener categoría");
    }

    return resultado.datos;
}

// Crear categoría
export async function crearCategoria(categoria) {
    return enviar(`${API_URL}/categorias`, "POST", categoria);
}

// Actualizar categoría
export async function actualizarCategoria(id, categoria) {
    return enviar(`${API_URL}/categorias/${id}`, "PUT", categoria);
}

// Eliminar categoría
export async function eliminarCategoria(id) {
    return enviar(`${API_URL}/categorias/${id}`, "DELETE");
}

// ==========================================
// FUNCIÓN GENERAL PARA ENVIAR PETICIONES
// ==========================================

async function enviar(url, metodo, datos = null) {
    const configuracion = {
        method: metodo,
        headers: {
            "Content-Type": "application/json"
        }
    };

    if (datos) {
        configuracion.body = JSON.stringify(datos);
    }

    const respuesta = await fetch(url, configuracion);

    const resultado = await respuesta.json();

    if (!respuesta.ok) {
        throw new Error(
            resultado.mensaje || "Ocurrió un error"
        );
    }

    return resultado;
}
