
import { useEffect, useState } from "react";
import {
    obtenerProductos,
    obtenerCategorias,
    crearProducto,
    actualizarProducto,
    eliminarProducto,
    crearCategoria,
    actualizarCategoria,
    eliminarCategoria
} from "./services/api";

import "./App.css";

function App() {
    const [pagina, setPagina] = useState("dashboard");
    const [productos, setProductos] = useState([]);
    const [categorias, setCategorias] = useState([]);
    const [busqueda, setBusqueda] = useState("");
    const [filtroCategoria, setFiltroCategoria] = useState("");
    const [modal, setModal] = useState(false);
    const [tipo, setTipo] = useState("producto");
    const [elementoEditar, setElementoEditar] = useState(null);
    const [cargando, setCargando] = useState(true);
    const [error, setError] = useState("");

    const [formulario, setFormulario] = useState({
        nombre: "",
        descripcion: "",
        precio: "",
        stock: "",
        categoriaId: ""
    });

    async function cargarDatos() {
        try {
            setCargando(true);
            setError("");

            const [listaProductos, listaCategorias] = await Promise.all([
                obtenerProductos(busqueda, filtroCategoria),
                obtenerCategorias()
            ]);

            setProductos(listaProductos);
            setCategorias(listaCategorias);
        } catch (err) {
            setError(err.message);
        } finally {
            setCargando(false);
        }
    }

    useEffect(() => {
        cargarDatos();
    }, [busqueda, filtroCategoria]);

    function abrirModal(tipoElemento, elemento = null) {
        setTipo(tipoElemento);
        setElementoEditar(elemento);

        if (elemento) {
            setFormulario({
                nombre: elemento.nombre || "",
                descripcion: elemento.descripcion || "",
                precio: elemento.precio ?? "",
                stock: elemento.stock ?? "",
                categoriaId: elemento.categoriaId ?? ""
            });
        } else {
            setFormulario({
                nombre: "",
                descripcion: "",
                precio: "",
                stock: "",
                categoriaId: categorias[0]?.id || ""
            });
        }

        setModal(true);
    }

    function cerrarModal() {
        setModal(false);
        setElementoEditar(null);
    }

    function cambiarFormulario(e) {
        setFormulario({
            ...formulario,
            [e.target.name]: e.target.value
        });
    }

    async function guardar(e) {
        e.preventDefault();

        try {
            if (tipo === "producto") {
                const datos = {
                    nombre: formulario.nombre.trim(),
                    descripcion: formulario.descripcion.trim(),
                    precio: Number(formulario.precio),
                    stock: Number(formulario.stock),
                    categoriaId: Number(formulario.categoriaId)
                };

                if (elementoEditar) {
                    await actualizarProducto(elementoEditar.id, datos);
                } else {
                    await crearProducto(datos);
                }
            } else {
                const datos = {
                    nombre: formulario.nombre.trim(),
                    descripcion: formulario.descripcion.trim()
                };

                if (elementoEditar) {
                    await actualizarCategoria(elementoEditar.id, datos);
                } else {
                    await crearCategoria(datos);
                }
            }

            cerrarModal();
            await cargarDatos();
        } catch (err) {
            alert(err.message);
        }
    }

    async function borrarProducto(id) {
        if (!confirm("¿Estás seguro de eliminar este producto?")) return;

        try {
            await eliminarProducto(id);
            await cargarDatos();
        } catch (err) {
            alert(err.message);
        }
    }

    async function borrarCategoria(id) {
        if (!confirm("¿Estás seguro de eliminar esta categoría?")) return;

        try {
            await eliminarCategoria(id);
            await cargarDatos();
        } catch (err) {
            alert(err.message);
        }
    }

    const productosBajoStock = productos.filter(p => Number(p.stock) <= 5);

    const valorInventario = productos.reduce(
        (total, p) => total + Number(p.precio) * Number(p.stock),
        0
    );

    return (
        <div className="app-container">

            <aside className="sidebar">
                <div className="logo">
                    <div className="logo-icon">🔨</div>
                    <div>
                        <h2>FERREMAX</h2>
                        <span>Gestión de ferretería</span>
                    </div>
                </div>

                <div className="menu-title">MENÚ PRINCIPAL</div>

                <nav>
                    <button
                        className={pagina === "dashboard" ? "menu-item active" : "menu-item"}
                        onClick={() => setPagina("dashboard")}
                    >
                        <span>▦</span> Dashboard
                    </button>

                    <button
                        className={pagina === "productos" ? "menu-item active" : "menu-item"}
                        onClick={() => setPagina("productos")}
                    >
                        <span>📦</span> Productos
                    </button>

                    <button
                        className={pagina === "categorias" ? "menu-item active" : "menu-item"}
                        onClick={() => setPagina("categorias")}
                    >
                        <span>▤</span> Categorías
                    </button>
                </nav>

                <div className="sidebar-footer">
                    <div className="user-avatar">A</div>
                    <div>
                        <strong>Administrador</strong>
                        <span>Panel de control</span>
                    </div>
                </div>
            </aside>

            <main className="main-content">

                <header className="topbar">
                    <div>
                        <h2>
                            {pagina === "dashboard" && "Dashboard"}
                            {pagina === "productos" && "Gestión de productos"}
                            {pagina === "categorias" && "Gestión de categorías"}
                        </h2>
                        <p>Bienvenido al sistema de gestión de FerreMax</p>
                    </div>

                    <div className="topbar-right">
                        <span className="status-dot"></span>
                        Sistema conectado
                    </div>
                </header>

                {error && (
                    <div className="error-message">
                        ⚠️ {error}
                        <button onClick={cargarDatos}>Reintentar</button>
                    </div>
                )}

                {cargando ? (
                    <div className="loading">Cargando información...</div>
                ) : (
                    <>

                        {pagina === "dashboard" && (
                            <section className="content">

                                <div className="welcome">
                                    <div>
                                        <h1>Panel de administración</h1>
                                        <p>Controla tus productos y categorías desde un solo lugar.</p>
                                    </div>
                                    <span>🛠️</span>
                                </div>

                                <div className="stats-grid">
                                    <div className="stat-card">
                                        <div className="stat-icon purple">📦</div>
                                        <p>Total de productos</p>
                                        <h2>{productos.length}</h2>
                                    </div>

                                    <div className="stat-card">
                                        <div className="stat-icon orange">📁</div>
                                        <p>Categorías registradas</p>
                                        <h2>{categorias.length}</h2>
                                    </div>

                                    <div className="stat-card">
                                        <div className="stat-icon green">💰</div>
                                        <p>Valor del inventario</p>
                                        <h2>Bs. {valorInventario.toFixed(2)}</h2>
                                    </div>

                                    <div className="stat-card">
                                        <div className="stat-icon red">⚠️</div>
                                        <p>Productos con poco stock</p>
                                        <h2>{productosBajoStock.length}</h2>
                                    </div>
                                </div>

                                <div className="section-heading">
                                    <div>
                                        <h2>Productos recientes</h2>
                                        <p>Últimos productos registrados en el sistema</p>
                                    </div>

                                    <button
                                        className="primary-button"
                                        onClick={() => setPagina("productos")}
                                    >
                                        Ver productos →
                                    </button>
                                </div>

                                <div className="table-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Producto</th>
                                                <th>Categoría</th>
                                                <th>Precio</th>
                                                <th>Stock</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {productos.slice(-5).reverse().map(p => (
                                                <tr key={p.id}>
                                                    <td><strong>{p.nombre}</strong></td>
                                                    <td>{p.categoriaNombre}</td>
                                                    <td>Bs. {Number(p.precio).toFixed(2)}</td>
                                                    <td>
                                                        <span className={Number(p.stock) <= 5 ? "stock-low" : "stock-ok"}>
                                                            {p.stock} unidades
                                                        </span>
                                                    </td>
                                                </tr>
                                            ))}

                                            {productos.length === 0 && (
                                                <tr>
                                                    <td colSpan="4" className="empty">
                                                        No hay productos registrados.
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        )}

                        {pagina === "productos" && (
                            <section className="content">

                                <div className="section-heading">
                                    <div>
                                        <h1>Productos</h1>
                                        <p>Administra el inventario de tu ferretería.</p>
                                    </div>

                                    <button
                                        className="primary-button"
                                        onClick={() => abrirModal("producto")}
                                    >
                                        + Nuevo producto
                                    </button>
                                </div>

                                <div className="filters">
                                    <input
                                        type="text"
                                        placeholder="Buscar producto..."
                                        value={busqueda}
                                        onChange={e => setBusqueda(e.target.value)}
                                    />

                                    <select
                                        value={filtroCategoria}
                                        onChange={e => setFiltroCategoria(e.target.value)}
                                    >
                                        <option value="">Todas las categorías</option>
                                        {categorias.map(c => (
                                            <option key={c.id} value={c.id}>
                                                {c.nombre}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                <div className="table-container">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Producto</th>
                                                <th>Categoría</th>
                                                <th>Precio</th>
                                                <th>Stock</th>
                                                <th>Acciones</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {productos.map(p => (
                                                <tr key={p.id}>
                                                    <td>#{p.id}</td>
                                                    <td>
                                                        <strong>{p.nombre}</strong>
                                                        <small>{p.descripcion}</small>
                                                    </td>
                                                    <td>{p.categoriaNombre}</td>
                                                    <td>Bs. {Number(p.precio).toFixed(2)}</td>
                                                    <td>
                                                        <span className={Number(p.stock) <= 5 ? "stock-low" : "stock-ok"}>
                                                            {p.stock}
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div className="actions">
                                                            <button
                                                                className="edit-button"
                                                                onClick={() => abrirModal("producto", p)}
                                                            >
                                                                Editar
                                                            </button>

                                                            <button
                                                                className="delete-button"
                                                                onClick={() => borrarProducto(p.id)}
                                                            >
                                                                Eliminar
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}

                                            {productos.length === 0 && (
                                                <tr>
                                                    <td colSpan="6" className="empty">
                                                        No se encontraron productos.
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        )}

                        {pagina === "categorias" && (
                            <section className="content">

                                <div className="section-heading">
                                    <div>
                                        <h1>Categorías</h1>
                                        <p>Organiza los productos por categorías.</p>
                                    </div>

                                    <button
                                        className="primary-button"
                                        onClick={() => abrirModal("categoria")}
                                    >
                                        + Nueva categoría
                                    </button>
                                </div>

                                <div className="categories-grid">
                                    {categorias.map(c => (
                                        <div className="category-card" key={c.id}>
                                            <div className="category-icon">📁</div>

                                            <h3>{c.nombre}</h3>
                                            <p>{c.descripcion || "Sin descripción"}</p>

                                            <span>
                                                {c.cantidadProductos} productos
                                            </span>

                                            <div className="actions">
                                                <button
                                                    className="edit-button"
                                                    onClick={() => abrirModal("categoria", c)}
                                                >
                                                    Editar
                                                </button>

                                                <button
                                                    className="delete-button"
                                                    onClick={() => borrarCategoria(c.id)}
                                                >
                                                    Eliminar
                                                </button>
                                            </div>
                                        </div>
                                    ))}

                                    {categorias.length === 0 && (
                                        <p>No hay categorías registradas.</p>
                                    )}
                                </div>
                            </section>
                        )}

                    </>
                )}

            </main>

            {modal && (
                <div className="modal-overlay">
                    <div className="modal">

                        <div className="modal-header">
                            <div>
                                <h2>
                                    {elementoEditar ? "Editar" : "Registrar"}{" "}
                                    {tipo === "producto" ? "producto" : "categoría"}
                                </h2>
                                <p>Completa los datos del formulario.</p>
                            </div>

                            <button className="close-button" onClick={cerrarModal}>
                                ×
                            </button>
                        </div>

                        <form onSubmit={guardar}>

                            <label>Nombre</label>
                            <input
                                name="nombre"
                                value={formulario.nombre}
                                onChange={cambiarFormulario}
                                required
                                maxLength="100"
                                placeholder="Nombre"
                            />

                            <label>Descripción</label>
                            <textarea
                                name="descripcion"
                                value={formulario.descripcion}
                                onChange={cambiarFormulario}
                                maxLength="500"
                                placeholder="Descripción"
                                rows="3"
                            />

                            {tipo === "producto" && (
                                <>
                                    <label>Precio (Bs.)</label>
                                    <input
                                        type="number"
                                        name="precio"
                                        value={formulario.precio}
                                        onChange={cambiarFormulario}
                                        min="0.01"
                                        step="0.01"
                                        required
                                    />

                                    <label>Stock</label>
                                    <input
                                        type="number"
                                        name="stock"
                                        value={formulario.stock}
                                        onChange={cambiarFormulario}
                                        min="0"
                                        step="1"
                                        required
                                    />

                                    <label>Categoría</label>
                                    <select
                                        name="categoriaId"
                                        value={formulario.categoriaId}
                                        onChange={cambiarFormulario}
                                        required
                                    >
                                        <option value="">Seleccionar categoría</option>
                                        {categorias.map(c => (
                                            <option key={c.id} value={c.id}>
                                                {c.nombre}
                                            </option>
                                        ))}
                                    </select>
                                </>
                            )}

                            <div className="modal-actions">
                                <button
                                    type="button"
                                    className="cancel-button"
                                    onClick={cerrarModal}
                                >
                                    Cancelar
                                </button>

                                <button type="submit" className="primary-button">
                                    {elementoEditar ? "Guardar cambios" : "Registrar"}
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            )}

        </div>
    );
}

export default App;
  