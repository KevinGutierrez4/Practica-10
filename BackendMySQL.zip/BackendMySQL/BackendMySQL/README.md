# Backend de Ferreteria (Node.js + Express + MySQL)

Esta es la version que **cumple con el enunciado del profesor**, porque MySQL es obligatorio. Contiene solo el backend: API REST, SQL, datos de prueba, coleccion Postman y pruebas. **No incluye archivos `.cmd`, pagina web ni aplicacion movil.**

## Requisitos
- Node.js 20 o posterior.
- MySQL Server 8.x (MySQL Workbench es opcional para administrar).
- VS Code y Postman o Thunder Client.

## Instalacion desde VS Code (Windows PowerShell)
1. Abre esta carpeta en VS Code y abre su terminal.
2. Ejecuta `npm.cmd install` (usa `npm install` si tu terminal no bloquea scripts).
3. Ejecuta `Copy-Item .env.example .env` y edita `.env` con tu usuario y contrasena reales de MySQL.
4. Enciende MySQL Server. Ejecuta `npm.cmd run db:setup` para crear la base y las tablas.
5. Ejecuta `npm.cmd run db:seed` para insertar **7 categorias y 20 productos** de ejemplo.
6. Ejecuta `npm.cmd start` y visita `http://localhost:3000/api/salud`.
7. Para probar automaticamente la API abierta: en otra terminal ejecuta `npm.cmd run test:api`.
8. Para pruebas manuales, importa `postman/Ferreteria.postman_collection.json` a Postman.

Puedes ejecutar los archivos `sql/01_crear_base_de_datos.sql` y `sql/02_datos_de_prueba.sql` desde MySQL Workbench en vez de usar los comandos db:setup/db:seed.

## Tablas
- `categorias`: `id` (PK), `nombre`, `descripcion`.
- `productos`: `id` (PK), `nombre`, `descripcion`, `precio`, `stock`, `categoria_id` (FK).
- Relacion **1:N**: una categoria tiene muchos productos; un producto pertenece a una categoria. Se impide eliminar categorias con productos.

## Endpoints
| Metodo | Ruta | Funcion |
|---|---|---|
| GET | `/api/salud` | Estado y conexion de BD |
| GET | `/api/categorias` | Listar |
| GET | `/api/categorias/:id` | Consultar |
| POST | `/api/categorias` | Crear |
| PUT | `/api/categorias/:id` | Editar |
| DELETE | `/api/categorias/:id` | Eliminar |
| GET | `/api/productos` | Listar, buscar y filtrar |
| GET | `/api/productos/:id` | Consultar |
| POST | `/api/productos` | Crear |
| PUT | `/api/productos/:id` | Editar |
| DELETE | `/api/productos/:id` | Eliminar |

El listado de productos admite `?buscar=martillo&categoriaId=1&pagina=1&limite=10`.

**POST /api/categorias**
```json
{ "nombre": "Adhesivos", "descripcion": "Pegamentos y selladores" }
```

**POST /api/productos**
```json
{ "nombre": "Silicona 300 ml", "descripcion": "Uso general", "precio": 25.90, "stock": 12, "categoriaId": 1 }
```

Se envian objetos JSON; el backend responde `datos`, `mensaje` y `paginacion` segun la ruta. Para editar con PUT se envian todos los campos requeridos.

## Conectar React y movil
- En la misma PC: `http://localhost:3000/api`.
- En celular fisico: `http://IP-REAL-DE-TU-PC:3000/api` (ambos dispositivos en la misma red Wi-Fi).
- El backend escucha en `0.0.0.0`, pero Windows Firewall puede necesitar una regla de red **privada** para el puerto 3000. No expongas la API publicamente sin HTTPS/autenticacion.
- En emulador Android, normalmente `http://10.0.2.2:3000/api`.
- Los clientes React y React Native/Flutter no se incluyen: el enunciado los asigna como trabajos separados.

## Archivos
`server.js` inicia Node; `src/app.js` configura Express; `src/db/pool.js` conecta MySQL; `src/routes/` define URLs; `src/controllers/` contiene consultas SQL; `src/utils/` valida; `sql/` contiene esquema y datos; `postman/` permite probar CRUD; `tests/` y `scripts/` permiten comprobaciones.

**Importante:** no subas tu `.env` real a GitHub; comparte solo `.env.example`.
