const db = require('../db/pool');
const { idPositivo, categoriaValida } = require('../utils/validaciones');

async function listar(req, res) {
  const [filas] = await db.execute(`
    SELECT c.id, c.nombre, c.descripcion, COUNT(p.id) AS cantidadProductos
    FROM categorias c
    LEFT JOIN productos p ON p.categoria_id = c.id
    GROUP BY c.id, c.nombre, c.descripcion
    ORDER BY c.id ASC
  `);
  res.json({ datos: filas.map(f => ({ ...f, cantidadProductos: Number(f.cantidadProductos) })), total: filas.length });
}

async function obtener(req, res) {
  const id = idPositivo(req.params.id);
  const [filas] = await db.execute(
    'SELECT id, nombre, descripcion FROM categorias WHERE id = ?', [id]);
  if (!filas.length) return res.status(404).json({ mensaje: 'Categoria no encontrada.' });
  res.json({ datos: filas[0] });
}

async function crear(req, res) {
  const c = categoriaValida(req.body);
  const [resultado] = await db.execute(
    'INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)',
    [c.nombre, c.descripcion]);
  res.status(201).json({ mensaje: 'Categoria creada.', datos: { id: resultado.insertId, ...c } });
}

async function actualizar(req, res) {
  const id = idPositivo(req.params.id);
  const c = categoriaValida(req.body);
  const [resultado] = await db.execute(
    'UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?',
    [c.nombre, c.descripcion, id]);
  if (!resultado.affectedRows) return res.status(404).json({ mensaje: 'Categoria no encontrada.' });
  res.json({ mensaje: 'Categoria actualizada.', datos: { id, ...c } });
}

async function eliminar(req, res) {
  const id = idPositivo(req.params.id);
  const [resultado] = await db.execute('DELETE FROM categorias WHERE id = ?', [id]);
  if (!resultado.affectedRows) return res.status(404).json({ mensaje: 'Categoria no encontrada.' });
  res.json({ mensaje: 'Categoria eliminada.' });
}

module.exports = { listar, obtener, crear, actualizar, eliminar };
