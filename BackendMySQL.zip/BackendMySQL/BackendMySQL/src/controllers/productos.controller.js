const db = require('../db/pool');
const { idPositivo, productoValido, cadena, errorValidacion } = require('../utils/validaciones');

function mapear(row) {
  return {
    id: row.id,
    nombre: row.nombre,
    descripcion: row.descripcion,
    precio: Number(row.precio),
    stock: row.stock,
    categoriaId: row.categoria_id,
    categoriaNombre: row.categoria_nombre
  };
}

const consultaBase = `
  SELECT p.id, p.nombre, p.descripcion, p.precio, p.stock,
         p.categoria_id, c.nombre AS categoria_nombre
  FROM productos p INNER JOIN categorias c ON c.id = p.categoria_id`;

async function listar(req, res) {
  const pagina = req.query.pagina === undefined ? 1 : idPositivo(req.query.pagina, 'pagina');
  const limite = req.query.limite === undefined ? 10 : idPositivo(req.query.limite, 'limite');
  if (limite > 100) throw errorValidacion('limite no puede superar 100.');
  const offset = (pagina - 1) * limite;
  if (!Number.isSafeInteger(offset)) throw errorValidacion('pagina demasiado grande.');

  const filtro = [];
  const params = [];
  if (req.query.buscar !== undefined) {
    const buscar = cadena(req.query.buscar, 'buscar', 100, false);
    if (buscar) {
      filtro.push('(p.nombre LIKE ? OR p.descripcion LIKE ?)');
      params.push(`%${buscar}%`, `%${buscar}%`);
    }
  }
  if (req.query.categoriaId !== undefined) {
    filtro.push('p.categoria_id = ?');
    params.push(idPositivo(req.query.categoriaId, 'categoriaId'));
  }
  const where = filtro.length ? ` WHERE ${filtro.join(' AND ')}` : '';
  const [cuenta] = await db.execute(
    `SELECT COUNT(*) AS total FROM productos p${where}`, params);
  const [filas] = await db.execute(
    `${consultaBase}${where} ORDER BY p.id ASC LIMIT ? OFFSET ?`, [...params, limite, offset]);
  const total = Number(cuenta[0].total);
  res.json({
    datos: filas.map(mapear),
    paginacion: { pagina, limite, total, totalPaginas: Math.ceil(total / limite) }
  });
}

async function obtener(req, res) {
  const id = idPositivo(req.params.id);
  const [filas] = await db.execute(`${consultaBase} WHERE p.id = ?`, [id]);
  if (!filas.length) return res.status(404).json({ mensaje: 'Producto no encontrado.' });
  res.json({ datos: mapear(filas[0]) });
}

async function buscarCategoria(categoriaId) {
  const [categorias] = await db.execute('SELECT nombre FROM categorias WHERE id = ?', [categoriaId]);
  if (!categorias.length) throw errorValidacion('categoriaId no corresponde a una categoria existente.');
  return categorias[0].nombre;
}

async function crear(req, res) {
  const p = productoValido(req.body);
  const categoriaNombre = await buscarCategoria(p.categoriaId);
  const [resultado] = await db.execute(
    'INSERT INTO productos (nombre, descripcion, precio, stock, categoria_id) VALUES (?, ?, ?, ?, ?)',
    [p.nombre, p.descripcion, p.precio, p.stock, p.categoriaId]);
  res.status(201).json({
    mensaje: 'Producto creado.',
    datos: { id: resultado.insertId, ...p, precio: Number(p.precio), categoriaNombre }
  });
}

async function actualizar(req, res) {
  const id = idPositivo(req.params.id);
  const p = productoValido(req.body);
  const categoriaNombre = await buscarCategoria(p.categoriaId);
  const [resultado] = await db.execute(
    `UPDATE productos SET nombre = ?, descripcion = ?, precio = ?, stock = ?, categoria_id = ?
     WHERE id = ?`,
    [p.nombre, p.descripcion, p.precio, p.stock, p.categoriaId, id]);
  if (!resultado.affectedRows) return res.status(404).json({ mensaje: 'Producto no encontrado.' });
  res.json({
    mensaje: 'Producto actualizado.',
    datos: { id, ...p, precio: Number(p.precio), categoriaNombre }
  });
}

async function eliminar(req, res) {
  const id = idPositivo(req.params.id);
  const [resultado] = await db.execute('DELETE FROM productos WHERE id = ?', [id]);
  if (!resultado.affectedRows) return res.status(404).json({ mensaje: 'Producto no encontrado.' });
  res.json({ mensaje: 'Producto eliminado.' });
}

module.exports = { listar, obtener, crear, actualizar, eliminar };
