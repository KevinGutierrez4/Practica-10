function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

function noEncontrado(req, res) {
  res.status(404).json({ mensaje: `Ruta no encontrada: ${req.method} ${req.originalUrl}` });
}

function manejarErrores(err, req, res, next) { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ mensaje: 'El cuerpo de la solicitud no es JSON valido.' });
  }
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ mensaje: 'Ya existe un registro con ese nombre.' });
  }
  if (err.code === 'ER_ROW_IS_REFERENCED_2') {
    return res.status(409).json({ mensaje: 'La categoria tiene productos asociados; no se puede eliminar.' });
  }
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({ mensaje: 'La categoria especificada no existe.' });
  }
  console.error('[API]', err);
  res.status(err.status || 500).json({
    mensaje: err.status ? err.message : 'Error interno del servidor.'
  });
}

module.exports = { asyncHandler, noEncontrado, manejarErrores };
