const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const db = require('./db/pool');
const { asyncHandler, noEncontrado, manejarErrores } = require('./middlewares/errores');

const app = express();
app.disable('x-powered-by');
app.use(helmet());

const permitidos = (process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin(origin, callback) {
    if (!origin || permitidos.includes('*') || permitidos.includes(origin)) return callback(null, true);
    const err = new Error('Origen no permitido por CORS.');
    err.status = 403;
    callback(err);
  }
}));
app.use(express.json({ limit: '100kb' }));
app.use(morgan('dev'));

app.get('/', (req, res) => res.json({
  proyecto: 'Ferreteria API REST',
  tecnologia: 'Node.js + Express + MySQL',
  endpoints: { salud: '/api/salud', categorias: '/api/categorias', productos: '/api/productos' }
}));

app.get('/api/salud', asyncHandler(async (req, res) => {
  await db.query('SELECT 1');
  res.json({ estado: 'ok', baseDeDatos: 'conectada' });
}));

app.use('/api/categorias', require('./routes/categorias.routes'));
app.use('/api/productos', require('./routes/productos.routes'));
app.use(noEncontrado);
app.use(manejarErrores);
module.exports = app;
