function errorValidacion(mensaje) {
  const error = new Error(mensaje);
  error.status = 400;
  return error;
}

function idPositivo(valor, campo = 'id') {
  const n = Number(valor);
  if (!/^\d+$/.test(String(valor)) || !Number.isSafeInteger(n) || n < 1) {
    throw errorValidacion(`${campo} debe ser un entero positivo.`);
  }
  return n;
}

function cadena(valor, campo, maximo, obligatoria = true) {
  if (valor === undefined || valor === null) {
    if (obligatoria) throw errorValidacion(`${campo} es obligatorio.`);
    return '';
  }
  if (typeof valor !== 'string') throw errorValidacion(`${campo} debe ser texto.`);
  const texto = valor.trim();
  if (obligatoria && !texto) throw errorValidacion(`${campo} es obligatorio.`);
  if (texto.length > maximo) throw errorValidacion(`${campo} no puede tener mas de ${maximo} caracteres.`);
  return texto;
}

function precioValido(valor) {
  const texto = typeof valor === 'number' && Number.isFinite(valor)
    ? String(valor) : valor;
  if (typeof texto !== 'string' || !/^\d+(\.\d{1,2})?$/.test(texto)) {
    throw errorValidacion('precio debe ser un numero no negativo con hasta 2 decimales.');
  }
  const n = Number(texto);
  if (!Number.isFinite(n) || n > 99999999.99) {
    throw errorValidacion('precio fuera de rango (maximo 99999999.99).');
  }
  return n.toFixed(2);
}

function stockValido(valor) {
  const texto = typeof valor === 'number' ? String(valor) : valor;
  if (typeof texto !== 'string' || !/^\d+$/.test(texto)) {
    throw errorValidacion('stock debe ser un numero entero no negativo.');
  }
  const n = Number(texto);
  if (!Number.isSafeInteger(n) || n > 100000000) {
    throw errorValidacion('stock fuera de rango (maximo 100000000).');
  }
  return n;
}

function categoriaValida(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw errorValidacion('Se espera un objeto JSON.');
  }
  return {
    nombre: cadena(body.nombre, 'nombre', 100),
    descripcion: cadena(body.descripcion, 'descripcion', 500, false)
  };
}

function productoValido(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw errorValidacion('Se espera un objeto JSON.');
  }
  return {
    nombre: cadena(body.nombre, 'nombre', 120),
    descripcion: cadena(body.descripcion, 'descripcion', 1000, false),
    precio: precioValido(body.precio),
    stock: stockValido(body.stock),
    categoriaId: idPositivo(body.categoriaId, 'categoriaId')
  };
}

module.exports = {
  errorValidacion, idPositivo, cadena, precioValido, stockValido,
  categoriaValida, productoValido
};
