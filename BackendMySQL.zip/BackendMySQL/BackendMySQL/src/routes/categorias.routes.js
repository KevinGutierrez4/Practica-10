const router = require('express').Router();
const c = require('../controllers/categorias.controller');
const { asyncHandler } = require('../middlewares/errores');

router.get('/', asyncHandler(c.listar));
router.get('/:id', asyncHandler(c.obtener));
router.post('/', asyncHandler(c.crear));
router.put('/:id', asyncHandler(c.actualizar));
router.delete('/:id', asyncHandler(c.eliminar));

module.exports = router;
