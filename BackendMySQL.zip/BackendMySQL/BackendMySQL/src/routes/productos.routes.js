const router = require('express').Router();
const p = require('../controllers/productos.controller');
const { asyncHandler } = require('../middlewares/errores');

router.get('/', asyncHandler(p.listar));
router.get('/:id', asyncHandler(p.obtener));
router.post('/', asyncHandler(p.crear));
router.put('/:id', asyncHandler(p.actualizar));
router.delete('/:id', asyncHandler(p.eliminar));

module.exports = router;
