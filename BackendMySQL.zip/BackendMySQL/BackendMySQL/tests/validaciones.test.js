const test = require('node:test');
const assert = require('node:assert/strict');
const { categoriaValida, productoValido, idPositivo } = require('../src/utils/validaciones');

test('categoria valida con nombre y descripcion', () => {
  assert.deepEqual(categoriaValida({ nombre: ' Tornillos ', descripcion: ' Fijaciones ' }),
    { nombre: 'Tornillos', descripcion: 'Fijaciones' });
});

test('categoria requiere nombre', () => {
  assert.throws(() => categoriaValida({ nombre: ' ' }), /nombre es obligatorio/);
});

test('producto valido acepta valores de formularios movil como texto', () => {
  assert.deepEqual(productoValido({ nombre: 'Martillo', precio: '35.50', stock: '2', categoriaId: '1' }),
    { nombre: 'Martillo', descripcion: '', precio: '35.50', stock: 2, categoriaId: 1 });
});

test('precio negativo es invalido', () => {
  assert.throws(() => productoValido({ nombre: 'Martillo', precio: -1, stock: 2, categoriaId: 1 }), /precio/);
});

test('precio con 3 decimales es invalido', () => {
  assert.throws(() => productoValido({ nombre: 'Martillo', precio: '1.234', stock: 2, categoriaId: 1 }), /precio/);
});

test('stock decimal o negativo es invalido', () => {
  assert.throws(() => productoValido({ nombre: 'Martillo', precio: 12, stock: 2.5, categoriaId: 1 }), /stock/);
  assert.throws(() => productoValido({ nombre: 'Martillo', precio: 12, stock: -1, categoriaId: 1 }), /stock/);
});

test('categoriaId debe ser positivo', () => {
  assert.equal(idPositivo('5'), 5);
  for (const malo of ['0', '-2', '1.5', 'abc']) assert.throws(() => idPositivo(malo), /entero positivo/);
});

test('no acepta nombre superior al limite', () => {
  assert.throws(() => categoriaValida({ nombre: 'a'.repeat(101) }), /100 caracteres/);
});
