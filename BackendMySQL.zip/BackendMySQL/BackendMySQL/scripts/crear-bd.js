require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function main() {
  const nombreBD = process.env.DB_NAME || 'ferreteria_db';
  if (!/^[A-Za-z0-9_]+$/.test(nombreBD)) throw new Error('DB_NAME debe usar solo letras, numeros y _.');
  const conexion = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true
  });
  try {
    const sql = fs.readFileSync(path.join(__dirname, '..', 'sql', '01_crear_base_de_datos.sql'), 'utf8')
      .replaceAll('ferreteria_db', nombreBD);
    await conexion.query(sql);
    console.log(`Base de datos y tablas listas: ${nombreBD}`);
  } finally {
    await conexion.end();
  }
}

main().catch(error => { console.error('Error al crear base de datos:', error.message); process.exitCode = 1; });
