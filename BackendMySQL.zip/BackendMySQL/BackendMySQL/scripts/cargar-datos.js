require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function main() {
  const nombreBD = process.env.DB_NAME || 'ferreteria_db';
  if (!/^[A-Za-z0-9_]+$/.test(nombreBD)) throw new Error('DB_NAME debe usar solo letras, numeros y _.');
  const conexion = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: nombreBD,
    multipleStatements: true
  });
  try {
    const sql = fs.readFileSync(path.join(__dirname, '..', 'sql', '02_datos_de_prueba.sql'), 'utf8')
      .replaceAll('ferreteria_db', nombreBD);
    await conexion.query(sql);
    const [[{ categorias }]] = await conexion.query('SELECT COUNT(*) AS categorias FROM categorias');
    const [[{ productos }]] = await conexion.query('SELECT COUNT(*) AS productos FROM productos');
    console.log(`Datos de prueba listos: ${categorias} categorias, ${productos} productos.`);
  } finally {
    await conexion.end();
  }
}

main().catch(error => { console.error('Error cargando datos:', error.message); process.exitCode = 1; });
