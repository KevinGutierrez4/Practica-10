// Prueba integral: requiere que MySQL y la API ya esten encendidos.
// Ejecutar en otra terminal: npm run test:api
const base = process.env.API_TEST_URL || 'http://localhost:3000/api';
let categoriaId;
let productoId;
let errores = 0;

async function pedir(ruta, metodo = 'GET', cuerpo) {
  const respuesta = await fetch(base + ruta, {
    method: metodo,
    headers: cuerpo === undefined ? {} : { 'Content-Type': 'application/json' },
    body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
    signal: AbortSignal.timeout(10000)
  });
  const json = await respuesta.json();
  return { status: respuesta.status, json };
}

function esperar(condicion, descripcion, respuesta) {
  if (!condicion) {
    errores++;
    console.error('ERROR:', descripcion, respuesta || '');
  } else {
    console.log('OK:', descripcion);
  }
}

async function main() {
  try {
    const salud = await pedir('/salud');
    esperar(salud.status === 200 && salud.json.estado === 'ok', 'Conexion con MySQL', salud);
    if (salud.status !== 200) return;

    const categorias = await pedir('/categorias');
    esperar(categorias.status === 200 && Array.isArray(categorias.json.datos), 'GET categorias', categorias);
    const productos = await pedir('/productos?pagina=1&limite=5');
    esperar(productos.status === 200 && Array.isArray(productos.json.datos), 'GET productos paginados', productos);

    const marca = Date.now();
    const nuevaCategoria = await pedir('/categorias', 'POST', {
      nombre: 'Categoria Test ' + marca, descripcion: 'Para prueba automatica'
    });
    categoriaId = nuevaCategoria.json.datos?.id;
    esperar(nuevaCategoria.status === 201 && Boolean(categoriaId), 'POST categoria', nuevaCategoria);
    if (!categoriaId) return;

    const nuevoProducto = await pedir('/productos', 'POST', {
      nombre: 'Producto Test ' + marca,
      descripcion: 'Para prueba automatica',
      precio: 15.50,
      stock: 8,
      categoriaId
    });
    productoId = nuevoProducto.json.datos?.id;
    esperar(nuevoProducto.status === 201 && Boolean(productoId), 'POST producto', nuevoProducto);
    if (!productoId) return;

    const detalle = await pedir('/productos/' + productoId);
    esperar(detalle.status === 200 && detalle.json.datos.categoriaId === categoriaId, 'GET producto por id', detalle);

    const modifica = await pedir('/productos/' + productoId, 'PUT', {
      nombre: 'Producto Test ' + marca,
      descripcion: 'Actualizado',
      precio: 22.25,
      stock: 4,
      categoriaId
    });
    esperar(modifica.status === 200 && modifica.json.datos.precio === 22.25, 'PUT producto', modifica);

    const invalido = await pedir('/productos', 'POST', {
      nombre: 'Con precio invalido', descripcion: '', precio: -20, stock: 1, categoriaId
    });
    esperar(invalido.status === 400, 'Valida precios negativos', invalido);

    const borradoBloqueado = await pedir('/categorias/' + categoriaId, 'DELETE');
    esperar(borradoBloqueado.status === 409, 'Impide eliminar categoria con productos', borradoBloqueado);

    const busca = await pedir('/productos?buscar=Producto%20Test&categoriaId=' + categoriaId);
    esperar(busca.status === 200 && busca.json.paginacion.total >= 1, 'Busqueda y filtro', busca);
  } catch (error) {
    errores++;
    console.error('No fue posible completar la prueba:', error.message);
    console.error('Comprueba que ejecutaste npm start y que /api/salud abre.');
  } finally {
    if (productoId) {
      try {
        const eliminado = await pedir('/productos/' + productoId, 'DELETE');
        esperar(eliminado.status === 200, 'DELETE producto / limpieza', eliminado);
      } catch (error) { errores++; console.error('No se pudo limpiar producto de prueba:', error.message); }
    }
    if (categoriaId) {
      try {
        const eliminada = await pedir('/categorias/' + categoriaId, 'DELETE');
        esperar(eliminada.status === 200, 'DELETE categoria / limpieza', eliminada);
      } catch (error) { errores++; console.error('No se pudo limpiar categoria de prueba:', error.message); }
    }
    console.log(errores === 0 ? '\nTODAS LAS PRUEBAS PASARON' : `\nFALLARON ${errores} COMPROBACIONES`);
    if (errores) process.exitCode = 1;
  }
}

main();
