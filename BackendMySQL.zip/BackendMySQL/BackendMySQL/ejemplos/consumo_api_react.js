// EJEMPLO para React web en la misma computadora del backend.
// No es un frontend completo. Se puede pegar la logica en un componente React.
const BASE_URL = 'http://localhost:3000/api';

export async function obtenerProductos() {
  const respuesta = await fetch(`${BASE_URL}/productos?limite=100`);
  if (!respuesta.ok) throw new Error('No se pudieron cargar productos');
  const json = await respuesta.json();
  return json.datos;
}

export async function registrarProducto(producto) {
  const respuesta = await fetch(`${BASE_URL}/productos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(producto)
  });
  const json = await respuesta.json();
  if (!respuesta.ok) throw new Error(json.mensaje);
  return json.datos;
}
