// EJEMPLO para React Native / Expo en telefono real.
// Usa la IPv4 de la PC que ejecuta el backend; localhost no apunta a esa PC.
const BASE_URL = 'http://192.168.1.100:3000/api'; // CAMBIAR por la IP real

export async function obtenerProductosMovil() {
  const respuesta = await fetch(`${BASE_URL}/productos?limite=100`);
  if (!respuesta.ok) throw new Error('Error consultando la API');
  return (await respuesta.json()).datos;
}
