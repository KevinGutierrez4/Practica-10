require('dotenv').config();
const app = require('./src/app');
const db = require('./src/db/pool');

async function iniciar() {
  const host = process.env.HOST || '0.0.0.0';
  const puerto = Number(process.env.PORT || 3000);
  if (!Number.isInteger(puerto) || puerto < 1 || puerto > 65535) {
    throw new Error('PORT debe ser un puerto valido.');
  }
  await db.query('SELECT 1');
  const servidor = app.listen(puerto, host, () => {
    console.log(`API Ferreteria escuchando en http://localhost:${puerto}`);
    console.log(`Desde otro dispositivo: http://IP-DE-TU-PC:${puerto}/api`);
    console.log(`Prueba de salud: http://localhost:${puerto}/api/salud`);
  });

  async function cerrar() {
    servidor.close(async () => {
      await db.end();
      process.exit(0);
    });
  }
  process.on('SIGINT', cerrar);
  process.on('SIGTERM', cerrar);
}

iniciar().catch(err => {
  console.error('No se pudo iniciar la API:', err.message);
  console.error('Comprueba que MySQL esta encendido, que .env sea correcto y que ejecutaste npm run db:setup.');
  process.exit(1);
});
