-- Cargar ejemplos sin duplicar: puede ejecutarse varias veces en una base nueva.
USE ferreteria_db;

INSERT INTO categorias (nombre, descripcion) VALUES
('Herramientas manuales', 'Martillos, alicates, destornilladores y llaves'),
('Herramientas electricas', 'Taladros, amoladoras y equipos electricos'),
('Pinturas', 'Pinturas, brochas y accesorios para pintar'),
('Electricidad', 'Cables, enchufes, interruptores y focos'),
('Plomeria', 'Tubos, griferia y accesorios de agua'),
('Construccion', 'Cemento, clavos, tornillos y otros materiales'),
('Seguridad', 'Equipos de proteccion personal')
ON DUPLICATE KEY UPDATE nombre = nombre;

INSERT INTO productos (nombre, descripcion, precio, stock, categoria_id)
SELECT d.nombre, d.descripcion, d.precio, d.stock, c.id
FROM (
  SELECT 'Martillo de una 16 oz' AS nombre, 'Martillo con mango de fibra' AS descripcion, 48.50 AS precio, 20 AS stock, 'Herramientas manuales' AS categoria
  UNION ALL SELECT 'Juego de destornilladores 6 piezas', 'Puntas planas y estrella', 69.90, 12, 'Herramientas manuales'
  UNION ALL SELECT 'Alicate universal 8 pulgadas', 'Mango antideslizante', 39.00, 15, 'Herramientas manuales'
  UNION ALL SELECT 'Llave francesa 10 pulgadas', 'Apertura ajustable', 55.00, 9, 'Herramientas manuales'
  UNION ALL SELECT 'Taladro percutor 650 W', 'Taladro con mandril de 13 mm', 420.00, 7, 'Herramientas electricas'
  UNION ALL SELECT 'Amoladora angular 4.5 pulgadas', 'Amoladora de 850 W', 390.00, 6, 'Herramientas electricas'
  UNION ALL SELECT 'Extensor electrico 5 m', 'Extension con 3 tomas', 58.00, 18, 'Electricidad'
  UNION ALL SELECT 'Cable electrico 2.5 mm 100 m', 'Rollo de cable de cobre', 325.00, 10, 'Electricidad'
  UNION ALL SELECT 'Foco LED 12 W', 'Luz blanca, bajo consumo', 18.00, 35, 'Electricidad'
  UNION ALL SELECT 'Interruptor simple', 'Para pared, color blanco', 12.50, 42, 'Electricidad'
  UNION ALL SELECT 'Pintura latex blanca 1 galon', 'Para interiores', 89.00, 11, 'Pinturas'
  UNION ALL SELECT 'Rodillo para pintura 9 pulgadas', 'Rodillo de felpa', 29.00, 25, 'Pinturas'
  UNION ALL SELECT 'Brocha 3 pulgadas', 'Cerdas sinteticas', 17.00, 30, 'Pinturas'
  UNION ALL SELECT 'Tubo PVC media pulgada 3 m', 'Tubo para instalaciones de agua', 22.00, 24, 'Plomeria'
  UNION ALL SELECT 'Codo PVC media pulgada', 'Conector en angulo de 90 grados', 2.80, 100, 'Plomeria'
  UNION ALL SELECT 'Llave de paso media pulgada', 'Valvula manual para agua', 32.00, 17, 'Plomeria'
  UNION ALL SELECT 'Cemento 50 kg', 'Bolsa de cemento para construccion', 68.00, 45, 'Construccion'
  UNION ALL SELECT 'Caja de clavos 2 pulgadas', 'Clavos de acero, caja de 1 kg', 24.00, 29, 'Construccion'
  UNION ALL SELECT 'Guantes de seguridad', 'Proteccion para trabajos manuales', 19.90, 38, 'Seguridad'
  UNION ALL SELECT 'Gafas de proteccion', 'Lentes transparentes de seguridad', 25.00, 21, 'Seguridad'
) AS d
JOIN categorias AS c ON c.nombre = d.categoria
LEFT JOIN productos AS p ON p.nombre = d.nombre
WHERE p.id IS NULL;
